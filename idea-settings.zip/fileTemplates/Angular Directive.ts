///<reference path="${DEF_PREFIX}_app.d.ts"/>
module $MODULE_NAME {
    'use strict';
    
    angular.module(MODULE_NAME)
        .directive('${NAME}', ${NAME});

    function ${NAME}():ng.IDirective {
        return {
            restrict: 'A',
            templateUrl: '/$MODULE_NAME/${NAME}',
            link: (scope:ng.IScope, element:ng.IAugmentedJQuery, attrs) => {
            }
        };
    }

}