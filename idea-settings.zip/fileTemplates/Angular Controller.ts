///<reference path="${DEF_PREFIX}_app.d.ts"/>
module $MODULE_NAME {
    'use strict';

    class ${NAME} {
        static CTRL_NAME = MODULE_NAME + '.${NAME}';
        
        constructor(${DS}scope:ng.IScope) {
        }
    }
    
    angular.module(MODULE_NAME)
        .controller(${NAME}.CTRL_NAME, ${NAME});
}